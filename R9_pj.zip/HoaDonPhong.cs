﻿using System;  
using System.Data;  
using System.Data.SqlClient;  
using System.Windows.Forms;  

namespace R9  
{  
    public partial class HoaDonPhong : Form  
    {  
        private string connectionString = "Data Source=PAU\\SQL_DEVELOPER;Initial Catalog=QLyNhaTro;Integrated Security=True";  
        private DataTable dtHoaDonPhong;  
        private int currentTenantId; // ID của người thuê  

        public HoaDonPhong(int tenantId) // Tham số để nhận ID người thuê  
        {  
            InitializeComponent();  
            currentTenantId = tenantId; // Gán ID người thuê  
        }  

        private void HoaDonPhong_Load(object sender, EventArgs e)  
        {  
            LoadHoaDonPhong();  
        }  

        private void LoadHoaDonPhong()  
        {  
            try  
            {  
                using (SqlConnection connection = new SqlConnection(connectionString))  
                {  
                    connection.Open();  
                    // Cập nhật truy vấn SQL để chỉ lấy hóa đơn của người thuê hiện tại  
                    string query = "SELECT BHD_idBanghoadon, BHD_ngaylaphoadon, BHD_tienphong, BHD_trangthai " +  
                                   "FROM BangHoaDon " +  
                                   "WHERE TT_id = @tenantId"; // Giả sử TT_id là ID người thuê trong bảng  

                    SqlCommand command = new SqlCommand(query, connection);  
                    command.Parameters.AddWithValue("@tenantId", currentTenantId); // Thêm tham số cho truy vấn  

                    SqlDataAdapter adapter = new SqlDataAdapter(command);  
                    dtHoaDonPhong = new DataTable();  
                    adapter.Fill(dtHoaDonPhong);  
                    dataGridViewHoaDonPhong.DataSource = dtHoaDonPhong;  

                    FilterHoaDonByStatus(0); // Lọc hóa đơn theo trạng thái chưa thanh toán  
                }  
            }  
            catch (Exception ex)  
            {  
                MessageBox.Show($"Lỗi khi tải dữ liệu hóa đơn: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);  
            }  
        }  

        private void FilterHoaDonByStatus(int status)  
        {  
            DataView dv = new DataView(dtHoaDonPhong);  
            dv.RowFilter = $"BHD_trangthai = {status}";  
            dataGridViewHoaDonPhong.DataSource = dv;  
        }  

        private void btnShowAll_Click(object sender, EventArgs e)  
        {  
            // Hiện hóa đơn của người thuê, không phải tất cả  
            LoadHoaDonPhong(); // Gọi lại phương thức để đảm bảo đang tải dữ liệu của người thuê  
        }  

        private void btnFilterUnpaid_Click(object sender, EventArgs e)  
        {  
            // Hiện hóa đơn chưa thanh toán  
            FilterHoaDonByStatus(0);  
        }  

        private void dataGridViewHoaDonPhong_CellContentClick(object sender, DataGridViewCellEventArgs e)  
        {  
            if (e.RowIndex >= 0 && e.ColumnIndex == 0) // Nếu click vào một hóa đơn  
            {  
                DataRowView row = (DataRowView)dataGridViewHoaDonPhong.Rows[e.RowIndex].DataBoundItem;  
                int maHoaDon = Convert.ToInt32(row["BHD_idBanghoadon"]);  
                ShowChiTietHoaDon(maHoaDon);  
            }  
        }  

        private void ShowChiTietHoaDon(int hoaDonId)  
        {  
            ChiTietHoaDon chiTietForm = new ChiTietHoaDon(hoaDonId);  
            chiTietForm.ShowDialog();  
        }  

        public void RefreshData()  
        {  
            LoadHoaDonPhong(); // Phương thức để làm mới dữ liệu  
        }  
    }  
}