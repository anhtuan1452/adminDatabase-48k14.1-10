﻿using System;  
using System.Data;  
using System.Data.SqlClient;  
using System.Windows.Forms;  

namespace R9  
{  
    public partial class ChiTietHoaDon : Form  
    {  
        private string connectionString = "Data Source=PAU\\SQL_DEVELOPER;Initial Catalog=QLyNhaTro;Integrated Security=True";  
        private int maHoaDon;  

        public ChiTietHoaDon(int idHoaDon)  
        {  
            InitializeComponent();  
            maHoaDon = idHoaDon;  
        }  

        private void ChiTietHoaDon_Load(object sender, EventArgs e)  
        {  
            LoadChiTietHoaDon();  
        }  

        private void LoadChiTietHoaDon()  
        {  
            try  
            {  
                using (SqlConnection connection = new SqlConnection(connectionString))  
                {  
                    connection.Open();  
                    string query = "SELECT CT_id, CT_soLuong, CT_giaTien " +  
                                   "FROM ChiTietHoaDon " +  
                                   "WHERE BHD_idBanghoadon = @maHoaDon"; // Thay đổi với tên bảng và cột đúng trong cơ sở dữ liệu  
                    SqlCommand command = new SqlCommand(query, connection);  
                    command.Parameters.AddWithValue("@maHoaDon", maHoaDon);  
                    SqlDataAdapter adapter = new SqlDataAdapter(command);  
                    DataTable dtChiTietHoaDon = new DataTable();  
                    adapter.Fill(dtChiTietHoaDon);  
                    dataGridViewChiTiet.DataSource = dtChiTietHoaDon;  
                }  
            }  
            catch (Exception ex)  
            {  
                MessageBox.Show($"Lỗi khi tải chi tiết hóa đơn: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);  
            }  
        }  
    }  
}