﻿namespace R9
{
    partial class XemHoaDon
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblMaHoaDon;
        private System.Windows.Forms.Label lblNgayLapHoaDon;
        private System.Windows.Forms.Label lblTienPhong;
        private System.Windows.Forms.Label lblTrangThai;
        private System.Windows.Forms.DataGridView dataGridViewDichVu;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblMaHoaDon = new System.Windows.Forms.Label();
            this.lblNgayLapHoaDon = new System.Windows.Forms.Label();
            this.lblTienPhong = new System.Windows.Forms.Label();
            this.lblTrangThai = new System.Windows.Forms.Label();
            this.dataGridViewDichVu = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDichVu)).BeginInit();
            this.SuspendLayout();
            //   
            // lblMaHoaDon  
            //   
            this.lblMaHoaDon.AutoSize = true;
            this.lblMaHoaDon.Location = new System.Drawing.Point(12, 20);
            this.lblMaHoaDon.Name = "lblMaHoaDon";
            this.lblMaHoaDon.Size = new System.Drawing.Size(92, 17);
            this.lblMaHoaDon.TabIndex = 0;
            this.lblMaHoaDon.Text = "Mã Hóa Đơn:";
            //   
            // lblNgayLapHoaDon  
            //   
            this.lblNgayLapHoaDon.AutoSize = true;
            this.lblNgayLapHoaDon.Location = new System.Drawing.Point(12, 50);
            this.lblNgayLapHoaDon.Name = "lblNgayLapHoaDon";
            this.lblNgayLapHoaDon.Size = new System.Drawing.Size(120, 17);
            this.lblNgayLapHoaDon.TabIndex = 1;
            this.lblNgayLapHoaDon.Text = "Ngày Lập HĐ:";
            //   
            // lblTienPhong  
            //   
            this.lblTienPhong.AutoSize = true;
            this.lblTienPhong.Location = new System.Drawing.Point(12, 80);
            this.lblTienPhong.Name = "lblTienPhong";
            this.lblTienPhong.Size = new System.Drawing.Size(83, 17);
            this.lblTienPhong.TabIndex = 2;
            this.lblTienPhong.Text = "Tiền Phòng:";
            //   
            // lblTrangThai  
            //   
            this.lblTrangThai.AutoSize = true;
            this.lblTrangThai.Location = new System.Drawing.Point(12, 110);
            this.lblTrangThai.Name = "lblTrangThai";
            this.lblTrangThai.Size = new System.Drawing.Size(77, 17);
            this.lblTrangThai.TabIndex = 3;
            this.lblTrangThai.Text = "Trạng Thái:";
            //   
            // dataGridViewDichVu  
            //   
            this.dataGridViewDichVu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDichVu.Location = new System.Drawing.Point(12, 140);
            this.dataGridViewDichVu.Name = "dataGridViewDichVu";
            this.dataGridViewDichVu.RowHeadersWidth = 51;
            this.dataGridViewDichVu.RowTemplate.Height = 24;
            this.dataGridViewDichVu.Size = new System.Drawing.Size(776, 298);
            this.dataGridViewDichVu.TabIndex = 4;
            //   
            // XemHoaDon  
            //   
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridViewDichVu);
            this.Controls.Add(this.lblTrangThai);
            this.Controls.Add(this.lblTienPhong);
            this.Controls.Add(this.lblNgayLapHoaDon);
            this.Controls.Add(this.lblMaHoaDon);
            this.Name = "XemHoaDon";
            this.Text = "Xem Hóa Đơn";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDichVu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}