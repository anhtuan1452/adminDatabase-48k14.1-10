﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace R9
{
    public partial class QuanlyDV : Form
    {
        private string connectionString = "Data Source=PAU\\SQL_DEVELOPER;Initial Catalog=QLyNhaTro;Integrated Security=True";
        private DataTable dtDichVu;

        public QuanlyDV()
        {
            InitializeComponent();
        }

        private void QuanlyDV_Load(object sender, EventArgs e)
        {
            LoadDichVu();
        }

        private void LoadDichVu()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT DV_iddichvu, DV_tendichvu, DV_tiencuadichvu FROM DichVu";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    dtDichVu = new DataTable();
                    adapter.Fill(dtDichVu);

                    dgvDichVu.DataSource = dtDichVu;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string tenDichVu = txtTenDichVu.Text;
            decimal giaDichVu = numericUpDownGiaDichVu.Value;

            if (string.IsNullOrWhiteSpace(tenDichVu))
            {
                MessageBox.Show("Tên dịch vụ không được để trống.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string insertQuery = "INSERT INTO DichVu (DV_tendichvu, DV_tiencuadichvu) VALUES (@TenDichVu, @GiaDichVu)";
                    using (SqlCommand command = new SqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@TenDichVu", tenDichVu);
                        command.Parameters.AddWithValue("@GiaDichVu", giaDichVu);
                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Thêm dịch vụ thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadDichVu();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thêm dịch vụ: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (dgvDichVu.SelectedRows.Count == 0)
            {
                MessageBox.Show("Hãy chọn một dịch vụ để sửa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int dichVuId = Convert.ToInt32(dgvDichVu.SelectedRows[0].Cells["DV_iddichvu"].Value);
            string tenDichVu = txtTenDichVu.Text;
            decimal giaDichVu = numericUpDownGiaDichVu.Value;

            if (string.IsNullOrWhiteSpace(tenDichVu))
            {
                MessageBox.Show("Tên dịch vụ không được để trống.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE DichVu SET DV_tendichvu = @TenDichVu, DV_tiencuadichvu = @GiaDichVu WHERE DV_iddichvu = @DichVuId";
                    using (SqlCommand command = new SqlCommand(updateQuery, connection))
                    {
                        command.Parameters.AddWithValue("@TenDichVu", tenDichVu);
                        command.Parameters.AddWithValue("@GiaDichVu", giaDichVu);
                        command.Parameters.AddWithValue("@DichVuId", dichVuId);
                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Sửa dịch vụ thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadDichVu();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi sửa dịch vụ: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dgvDichVu.SelectedRows.Count == 0)
            {
                MessageBox.Show("Hãy chọn một dịch vụ để xóa.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int dichVuId = Convert.ToInt32(dgvDichVu.SelectedRows[0].Cells["DV_iddichvu"].Value);

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string deleteQuery = "DELETE FROM DichVu WHERE DV_iddichvu = @DichVuId";
                    using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                    {
                        command.Parameters.AddWithValue("@DichVuId", dichVuId);
                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Xóa dịch vụ thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadDichVu();
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi xóa dịch vụ: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvDichVu_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvDichVu.SelectedRows.Count > 0)
            {
                txtTenDichVu.Text = dgvDichVu.SelectedRows[0].Cells["DV_tendichvu"].Value.ToString();
                numericUpDownGiaDichVu.Value = Convert.ToDecimal(dgvDichVu.SelectedRows[0].Cells["DV_tiencuadichvu"].Value);
            }
        }

        private void ClearForm()
        {
            txtTenDichVu.Text = "";
            numericUpDownGiaDichVu.Value = 0;
        }
    }
}
