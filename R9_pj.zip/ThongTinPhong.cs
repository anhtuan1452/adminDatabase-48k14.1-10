﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace R9
{
    public partial class ThongTinPhong : Form
    {
        private string connectionString = "Data Source=PAU\\SQL_DEVELOPER;Initial Catalog=QLyNhaTro;Integrated Security=True";
        private DataTable dtPhong;

        public ThongTinPhong()
        {
            InitializeComponent();
        }

        private void ThongTinPhong_Load(object sender, EventArgs e)
        {
            LoadThongTinPhong();
        }

        private void LoadThongTinPhong()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    // Cập nhật truy vấn SQL để lấy thông tin phòng  
                    string query = "SELECT P_id, P_sophong, P_giaphong, P_tinhtrangphong " +
                                   "FROM Phong"; // Tên bảng là Phong  

                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    dtPhong = new DataTable();
                    adapter.Fill(dtPhong);
                    dataGridViewPhong.DataSource = dtPhong;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tải thông tin phòng: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}