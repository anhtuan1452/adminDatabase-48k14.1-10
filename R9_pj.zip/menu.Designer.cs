﻿namespace R9
{
    partial class Menu1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.quảnLýPhòngTrọToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xemPhòngTrọToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmPhòngTrọToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sửaPhòngTrọToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýHóaĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xemHóaĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmHóaĐơnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýNgườiThuêPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xemNgườiThuêPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmNgườiThuêPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuct = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaNgườiThuêPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmNgườiThuêPhòngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýDịchVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xemDanhSáchDịchVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thêmDịchVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaDịchVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sửaDịchVụToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýChủTrọToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xemDanhSáchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmChủTrọToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaChủTrọToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sửaChủTrọToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýPhòngTrọToolStripMenuItem,
            this.quảnLýHóaĐơnToolStripMenuItem,
            this.quảnLýNgườiThuêPhòngToolStripMenuItem,
            this.quảnLýDịchVụToolStripMenuItem,
            this.quảnLýChủTrọToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // quảnLýPhòngTrọToolStripMenuItem
            // 
            this.quảnLýPhòngTrọToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xemPhòngTrọToolStripMenuItem,
            this.thêmPhòngTrọToolStripMenuItem,
            this.sửaPhòngTrọToolStripMenuItem,
            this.xóaToolStripMenuItem});
            this.quảnLýPhòngTrọToolStripMenuItem.Name = "quảnLýPhòngTrọToolStripMenuItem";
            this.quảnLýPhòngTrọToolStripMenuItem.Size = new System.Drawing.Size(143, 24);
            this.quảnLýPhòngTrọToolStripMenuItem.Text = "Quản lý phòng trọ";
            this.quảnLýPhòngTrọToolStripMenuItem.Click += new System.EventHandler(this.quảnLýPhòngTrọToolStripMenuItem_Click);
            // 
            // xemPhòngTrọToolStripMenuItem
            // 
            this.xemPhòngTrọToolStripMenuItem.Name = "xemPhòngTrọToolStripMenuItem";
            this.xemPhòngTrọToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.xemPhòngTrọToolStripMenuItem.Text = "Xem Phòng Trọ";
            // 
            // thêmPhòngTrọToolStripMenuItem
            // 
            this.thêmPhòngTrọToolStripMenuItem.Name = "thêmPhòngTrọToolStripMenuItem";
            this.thêmPhòngTrọToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.thêmPhòngTrọToolStripMenuItem.Text = "Thêm Phòng Trọ";
            // 
            // sửaPhòngTrọToolStripMenuItem
            // 
            this.sửaPhòngTrọToolStripMenuItem.Name = "sửaPhòngTrọToolStripMenuItem";
            this.sửaPhòngTrọToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.sửaPhòngTrọToolStripMenuItem.Text = "Sửa Phòng Trọ";
            // 
            // xóaToolStripMenuItem
            // 
            this.xóaToolStripMenuItem.Name = "xóaToolStripMenuItem";
            this.xóaToolStripMenuItem.Size = new System.Drawing.Size(200, 26);
            this.xóaToolStripMenuItem.Text = "Xóa Phòng Trọ";
            this.xóaToolStripMenuItem.Click += new System.EventHandler(this.xóaToolStripMenuItem_Click);
            // 
            // quảnLýHóaĐơnToolStripMenuItem
            // 
            this.quảnLýHóaĐơnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xemHóaĐơnToolStripMenuItem,
            this.tìmHóaĐơnToolStripMenuItem});
            this.quảnLýHóaĐơnToolStripMenuItem.Name = "quảnLýHóaĐơnToolStripMenuItem";
            this.quảnLýHóaĐơnToolStripMenuItem.Size = new System.Drawing.Size(132, 24);
            this.quảnLýHóaĐơnToolStripMenuItem.Text = "Quản lý hóa đơn";
            // 
            // xemHóaĐơnToolStripMenuItem
            // 
            this.xemHóaĐơnToolStripMenuItem.Name = "xemHóaĐơnToolStripMenuItem";
            this.xemHóaĐơnToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.xemHóaĐơnToolStripMenuItem.Text = "Xem hóa đơn";
            // 
            // tìmHóaĐơnToolStripMenuItem
            // 
            this.tìmHóaĐơnToolStripMenuItem.Name = "tìmHóaĐơnToolStripMenuItem";
            this.tìmHóaĐơnToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.tìmHóaĐơnToolStripMenuItem.Text = "Tìm Hóa Đơn";
            // 
            // quảnLýNgườiThuêPhòngToolStripMenuItem
            // 
            this.quảnLýNgườiThuêPhòngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xemNgườiThuêPhòngToolStripMenuItem,
            this.thêmNgườiThuêPhòngToolStripMenuItem,
            this.menuct,
            this.xóaNgườiThuêPhòngToolStripMenuItem,
            this.tìmNgườiThuêPhòngToolStripMenuItem});
            this.quảnLýNgườiThuêPhòngToolStripMenuItem.Name = "quảnLýNgườiThuêPhòngToolStripMenuItem";
            this.quảnLýNgườiThuêPhòngToolStripMenuItem.Size = new System.Drawing.Size(196, 24);
            this.quảnLýNgườiThuêPhòngToolStripMenuItem.Text = "Quản lý người thuê phòng";
            this.quảnLýNgườiThuêPhòngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýNgườiThuêPhòngToolStripMenuItem_Click);
            // 
            // xemNgườiThuêPhòngToolStripMenuItem
            // 
            this.xemNgườiThuêPhòngToolStripMenuItem.Name = "xemNgườiThuêPhòngToolStripMenuItem";
            this.xemNgườiThuêPhòngToolStripMenuItem.Size = new System.Drawing.Size(257, 26);
            this.xemNgườiThuêPhòngToolStripMenuItem.Text = "Xem Người Thuê Phòng";
            // 
            // thêmNgườiThuêPhòngToolStripMenuItem
            // 
            this.thêmNgườiThuêPhòngToolStripMenuItem.Name = "thêmNgườiThuêPhòngToolStripMenuItem";
            this.thêmNgườiThuêPhòngToolStripMenuItem.Size = new System.Drawing.Size(257, 26);
            this.thêmNgườiThuêPhòngToolStripMenuItem.Text = "Thêm Người Thuê Phòng";
            // 
            // menuct
            // 
            this.menuct.Name = "menuct";
            this.menuct.Size = new System.Drawing.Size(257, 26);
            this.menuct.Text = "Sửa Người Thuê Phòng";
            this.menuct.Click += new System.EventHandler(this.sửaNgườiThuêPhòngToolStripMenuItem_Click);
            // 
            // xóaNgườiThuêPhòngToolStripMenuItem
            // 
            this.xóaNgườiThuêPhòngToolStripMenuItem.Name = "xóaNgườiThuêPhòngToolStripMenuItem";
            this.xóaNgườiThuêPhòngToolStripMenuItem.Size = new System.Drawing.Size(257, 26);
            this.xóaNgườiThuêPhòngToolStripMenuItem.Text = "Xóa Người Thuê Phòng";
            this.xóaNgườiThuêPhòngToolStripMenuItem.Click += new System.EventHandler(this.xóaNgườiThuêPhòngToolStripMenuItem_Click);
            // 
            // tìmNgườiThuêPhòngToolStripMenuItem
            // 
            this.tìmNgườiThuêPhòngToolStripMenuItem.Name = "tìmNgườiThuêPhòngToolStripMenuItem";
            this.tìmNgườiThuêPhòngToolStripMenuItem.Size = new System.Drawing.Size(257, 26);
            this.tìmNgườiThuêPhòngToolStripMenuItem.Text = "Tìm Người Thuê Phòng";
            // 
            // quảnLýDịchVụToolStripMenuItem
            // 
            this.quảnLýDịchVụToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xemDanhSáchDịchVụToolStripMenuItem,
            this.thêmDịchVụToolStripMenuItem,
            this.xóaDịchVụToolStripMenuItem,
            this.sửaDịchVụToolStripMenuItem});
            this.quảnLýDịchVụToolStripMenuItem.Name = "quảnLýDịchVụToolStripMenuItem";
            this.quảnLýDịchVụToolStripMenuItem.Size = new System.Drawing.Size(130, 24);
            this.quảnLýDịchVụToolStripMenuItem.Text = "Quản Lý Dịch Vụ";
            this.quảnLýDịchVụToolStripMenuItem.Click += new System.EventHandler(this.quảnLýDịchVụToolStripMenuItem_Click);
            // 
            // xemDanhSáchDịchVụToolStripMenuItem
            // 
            this.xemDanhSáchDịchVụToolStripMenuItem.Name = "xemDanhSáchDịchVụToolStripMenuItem";
            this.xemDanhSáchDịchVụToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.xemDanhSáchDịchVụToolStripMenuItem.Text = "Xem Danh Sách Dịch Vụ";
            // 
            // thêmDịchVụToolStripMenuItem
            // 
            this.thêmDịchVụToolStripMenuItem.Name = "thêmDịchVụToolStripMenuItem";
            this.thêmDịchVụToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.thêmDịchVụToolStripMenuItem.Text = "Thêm Dịch Vụ";
            // 
            // xóaDịchVụToolStripMenuItem
            // 
            this.xóaDịchVụToolStripMenuItem.Name = "xóaDịchVụToolStripMenuItem";
            this.xóaDịchVụToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.xóaDịchVụToolStripMenuItem.Text = "Xóa Dịch Vụ";
            // 
            // sửaDịchVụToolStripMenuItem
            // 
            this.sửaDịchVụToolStripMenuItem.Name = "sửaDịchVụToolStripMenuItem";
            this.sửaDịchVụToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.sửaDịchVụToolStripMenuItem.Text = "Sửa Dịch Vụ";
            // 
            // quảnLýChủTrọToolStripMenuItem
            // 
            this.quảnLýChủTrọToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xemDanhSáchToolStripMenuItem,
            this.tìmChủTrọToolStripMenuItem,
            this.xóaChủTrọToolStripMenuItem,
            this.sửaChủTrọToolStripMenuItem});
            this.quảnLýChủTrọToolStripMenuItem.Name = "quảnLýChủTrọToolStripMenuItem";
            this.quảnLýChủTrọToolStripMenuItem.Size = new System.Drawing.Size(129, 24);
            this.quảnLýChủTrọToolStripMenuItem.Text = "Quản Lý Chủ Trọ";
            // 
            // xemDanhSáchToolStripMenuItem
            // 
            this.xemDanhSáchToolStripMenuItem.Name = "xemDanhSáchToolStripMenuItem";
            this.xemDanhSáchToolStripMenuItem.Size = new System.Drawing.Size(196, 26);
            this.xemDanhSáchToolStripMenuItem.Text = "Xem Danh Sách";
            // 
            // tìmChủTrọToolStripMenuItem
            // 
            this.tìmChủTrọToolStripMenuItem.Name = "tìmChủTrọToolStripMenuItem";
            this.tìmChủTrọToolStripMenuItem.Size = new System.Drawing.Size(196, 26);
            this.tìmChủTrọToolStripMenuItem.Text = "Tìm Chủ Trọ";
            // 
            // xóaChủTrọToolStripMenuItem
            // 
            this.xóaChủTrọToolStripMenuItem.Name = "xóaChủTrọToolStripMenuItem";
            this.xóaChủTrọToolStripMenuItem.Size = new System.Drawing.Size(196, 26);
            this.xóaChủTrọToolStripMenuItem.Text = "Xóa Chủ Trọ";
            this.xóaChủTrọToolStripMenuItem.Click += new System.EventHandler(this.xóaChủTrọToolStripMenuItem_Click);
            // 
            // sửaChủTrọToolStripMenuItem
            // 
            this.sửaChủTrọToolStripMenuItem.Name = "sửaChủTrọToolStripMenuItem";
            this.sửaChủTrọToolStripMenuItem.Size = new System.Drawing.Size(196, 26);
            this.sửaChủTrọToolStripMenuItem.Text = "Sửa Chủ Trọ";
            // 
            // Menu1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Menu1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Menu1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem quảnLýPhòngTrọToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xemPhòngTrọToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thêmPhòngTrọToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sửaPhòngTrọToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýHóaĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xemHóaĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýNgườiThuêPhòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xemNgườiThuêPhòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thêmNgườiThuêPhòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuct;
        private System.Windows.Forms.ToolStripMenuItem xóaNgườiThuêPhòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmHóaĐơnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmNgườiThuêPhòngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýDịchVụToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xemDanhSáchDịchVụToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thêmDịchVụToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaDịchVụToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sửaDịchVụToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýChủTrọToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xemDanhSáchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmChủTrọToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xóaChủTrọToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sửaChủTrọToolStripMenuItem;
    }
}

