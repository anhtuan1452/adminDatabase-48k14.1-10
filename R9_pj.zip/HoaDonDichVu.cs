﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace R9
{
    public partial class HoaDonDichVu : Form
    {
        private string connectionString = "Data Source=PAU\\SQL_DEVELOPER;Initial Catalog=QLyNhaTro;Integrated Security=True";
        private DataTable dtDichVu;
        private DataTable dtHoaDonDichVu;

        public HoaDonDichVu()
        {
            InitializeComponent();
        }

        private void HoaDonDichVu_Load(object sender, EventArgs e)
        {
            LoadDichVu();
            InitializeHoaDonDichVuTable();
        }

        private void LoadDichVu()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT DV_iddichvu, DV_tendichvu, DV_tiencuadichvu FROM DichVu";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    dtDichVu = new DataTable();
                    adapter.Fill(dtDichVu);
                    comboBoxDichVu.DataSource = dtDichVu;
                    comboBoxDichVu.DisplayMember = "DV_tendichvu";
                    comboBoxDichVu.ValueMember = "DV_iddichvu";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tải dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void InitializeHoaDonDichVuTable()
        {
            dtHoaDonDichVu = new DataTable();
            dtHoaDonDichVu.Columns.Add("DichVu", typeof(string));
            dtHoaDonDichVu.Columns.Add("SoLuong", typeof(int));
            dtHoaDonDichVu.Columns.Add("ThanhTien", typeof(decimal));
            dataGridViewDichVu.DataSource = dtHoaDonDichVu;
        }

        private void comboBoxDichVu_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxDichVu.SelectedItem != null)
            {
                DataRowView selectedRow = (DataRowView)comboBoxDichVu.SelectedItem;
                decimal giaDichVu = Convert.ToDecimal(selectedRow["DV_tiencuadichvu"]);
                labelGiaDichVu.Text = giaDichVu.ToString("C");
            }
        }

        private void btnThemDichVu_Click(object sender, EventArgs e)
        {
            if (comboBoxDichVu.SelectedItem == null || numericUpDownSoLuong.Value == 0)
            {
                MessageBox.Show("Vui lòng chọn dịch vụ và số lượng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataRowView selectedRow = (DataRowView)comboBoxDichVu.SelectedItem;
            string tenDichVu = selectedRow["DV_tendichvu"].ToString();
            decimal giaDichVu = Convert.ToDecimal(selectedRow["DV_tiencuadichvu"]);
            int soLuong = (int)numericUpDownSoLuong.Value;
            decimal thanhTien = giaDichVu * soLuong;

            dtHoaDonDichVu.Rows.Add(tenDichVu, soLuong, thanhTien);
            CalculateTotal();
        }

        private void CalculateTotal()
        {
            decimal total = 0;
            foreach (DataRow row in dtHoaDonDichVu.Rows)
            {
                total += Convert.ToDecimal(row["ThanhTien"]);
            }
            labelTotal.Text = total.ToString("C");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Code to save the invoice to the database, including the selected services
        }
    }
}
