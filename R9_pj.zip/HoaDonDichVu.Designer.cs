﻿namespace R9
{
    partial class HoaDonDichVu
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.comboBoxDichVu = new System.Windows.Forms.ComboBox();
            this.numericUpDownSoLuong = new System.Windows.Forms.NumericUpDown();
            this.labelGiaDichVu = new System.Windows.Forms.Label();
            this.btnThemDichVu = new System.Windows.Forms.Button();
            this.dataGridViewDichVu = new System.Windows.Forms.DataGridView();
            this.labelTotal = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.textBoxMaHoaDon = new System.Windows.Forms.TextBox();
            this.panelHeader = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSoLuong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDichVu)).BeginInit();
            this.panelHeader.SuspendLayout();
            this.SuspendLayout();

            // 
            // panelHeader
            // 
            this.panelHeader.Controls.Add(this.label1);
            this.panelHeader.Controls.Add(this.label2);
            this.panelHeader.Controls.Add(this.textBoxMaHoaDon);
            this.panelHeader.Controls.Add(this.dateTimePicker);
            this.panelHeader.Location = new System.Drawing.Point(150, 20);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(400, 60);
            this.panelHeader.TabIndex = 0;

            // 
            // comboBoxDichVu
            // 
            this.comboBoxDichVu.FormattingEnabled = true;
            this.comboBoxDichVu.Location = new System.Drawing.Point(150, 100);
            this.comboBoxDichVu.Name = "comboBoxDichVu";
            this.comboBoxDichVu.Size = new System.Drawing.Size(220, 21);
            this.comboBoxDichVu.TabIndex = 1;
            this.comboBoxDichVu.SelectedIndexChanged += new System.EventHandler(this.comboBoxDichVu_SelectedIndexChanged);

            // 
            // numericUpDownSoLuong
            // 
            this.numericUpDownSoLuong.Location = new System.Drawing.Point(150, 140);
            this.numericUpDownSoLuong.Name = "numericUpDownSoLuong";
            this.numericUpDownSoLuong.Size = new System.Drawing.Size(220, 20);
            this.numericUpDownSoLuong.TabIndex = 2;

            // 
            // labelGiaDichVu
            // 
            this.labelGiaDichVu.AutoSize = true;
            this.labelGiaDichVu.Location = new System.Drawing.Point(150, 180);
            this.labelGiaDichVu.Name = "labelGiaDichVu";
            this.labelGiaDichVu.Size = new System.Drawing.Size(40, 13);
            this.labelGiaDichVu.TabIndex = 3;
            this.labelGiaDichVu.Text = "Giá trị:";

            // 
            // btnThemDichVu
            // 
            this.btnThemDichVu.Location = new System.Drawing.Point(150, 210);
            this.btnThemDichVu.Name = "btnThemDichVu";
            this.btnThemDichVu.Size = new System.Drawing.Size(220, 30);
            this.btnThemDichVu.TabIndex = 4;
            this.btnThemDichVu.Text = "Thêm Dịch Vụ";
            this.btnThemDichVu.UseVisualStyleBackColor = true;
            this.btnThemDichVu.Click += new System.EventHandler(this.btnThemDichVu_Click);

            // 
            // dataGridViewDichVu
            // 
            this.dataGridViewDichVu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDichVu.Location = new System.Drawing.Point(150, 250);
            this.dataGridViewDichVu.Name = "dataGridViewDichVu";
            this.dataGridViewDichVu.Size = new System.Drawing.Size(500, 180);
            this.dataGridViewDichVu.TabIndex = 5;

            // 
            // labelTotal
            // 
            this.labelTotal.AutoSize = true;
            this.labelTotal.Location = new System.Drawing.Point(150, 450);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(61, 13);
            this.labelTotal.TabIndex = 6;
            this.labelTotal.Text = "Tổng tiền: ";

            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(150, 470);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(220, 30);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Lưu Hóa Đơn";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã Hóa Đơn";

            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(200, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ngày Hóa Đơn";

            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(200, 30);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker.TabIndex = 3;

            // 
            // textBoxMaHoaDon
            // 
            this.textBoxMaHoaDon.Location = new System.Drawing.Point(0, 30);
            this.textBoxMaHoaDon.Name = "textBoxMaHoaDon";
            this.textBoxMaHoaDon.Size = new System.Drawing.Size(200, 20);
            this.textBoxMaHoaDon.TabIndex = 2;

            // 
            // HoaDonDichVu
            // 
            this.ClientSize = new System.Drawing.Size(800, 520);
            this.Controls.Add(this.panelHeader);
            this.Controls.Add(this.comboBoxDichVu);
            this.Controls.Add(this.numericUpDownSoLuong);
            this.Controls.Add(this.labelGiaDichVu);
            this.Controls.Add(this.btnThemDichVu);
            this.Controls.Add(this.dataGridViewDichVu);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.btnSave);
            this.Name = "HoaDonDichVu";
            this.Text = "Hóa Đơn Dịch Vụ";
            this.Load += new System.EventHandler(this.HoaDonDichVu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSoLuong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDichVu)).EndInit();
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxDichVu;
        private System.Windows.Forms.NumericUpDown numericUpDownSoLuong;
        private System.Windows.Forms.Label labelGiaDichVu;
        private System.Windows.Forms.Button btnThemDichVu;
        private System.Windows.Forms.DataGridView dataGridViewDichVu;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.TextBox textBoxMaHoaDon;
        private System.Windows.Forms.Panel panelHeader;
    }
}
