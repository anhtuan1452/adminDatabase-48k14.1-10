﻿namespace R9  
{  
    partial class ChiTietHoaDon  
    {  
        private System.ComponentModel.IContainer components = null;  

        protected override void Dispose(bool disposing)  
        {  
            if (disposing && (components != null))  
            {  
                components.Dispose();  
            }  
            base.Dispose(disposing);  
        }  

        private void InitializeComponent()  
        {  
            this.dataGridViewChiTiet = new System.Windows.Forms.DataGridView();  
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewChiTiet)).BeginInit();  
            this.SuspendLayout();  
            //   
            // dataGridViewChiTiet  
            //   
            this.dataGridViewChiTiet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;  
            this.dataGridViewChiTiet.Location = new System.Drawing.Point(12, 12);  
            this.dataGridViewChiTiet.Name = "dataGridViewChiTiet";  
            this.dataGridViewChiTiet.RowHeadersWidth = 51;  
            this.dataGridViewChiTiet.RowTemplate.Height = 24;  
            this.dataGridViewChiTiet.Size = new System.Drawing.Size(776, 378);  
            this.dataGridViewChiTiet.TabIndex = 0;  
            //   
            // ChiTietHoaDon  
            //   
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);  
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;  
            this.ClientSize = new System.Drawing.Size(800, 450);  
            this.Controls.Add(this.dataGridViewChiTiet);  
            this.Name = "ChiTietHoaDon";  
            this.Text = "Chi Tiết Hóa Đơn";  
            this.Load += new System.EventHandler(this.ChiTietHoaDon_Load);  
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewChiTiet)).EndInit();  
            this.ResumeLayout(false);  
        }  

        private System.Windows.Forms.DataGridView dataGridViewChiTiet;  
    }  
}