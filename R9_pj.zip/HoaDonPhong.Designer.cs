﻿namespace R9  
{  
    partial class HoaDonPhong  
    {  
        private System.ComponentModel.IContainer components = null;  

        protected override void Dispose(bool disposing)  
        {  
            if (disposing && (components != null))  
            {  
                components.Dispose();  
            }  
            base.Dispose(disposing);  
        }  

        private void InitializeComponent()  
        {  
            this.dataGridViewHoaDonPhong = new System.Windows.Forms.DataGridView();  
            this.btnFilterUnpaid = new System.Windows.Forms.Button();  
            this.btnShowAll = new System.Windows.Forms.Button();  
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHoaDonPhong)).BeginInit();  
            this.SuspendLayout();  
            //   
            // dataGridViewHoaDonPhong  
            //   
            this.dataGridViewHoaDonPhong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;  
            this.dataGridViewHoaDonPhong.Location = new System.Drawing.Point(12, 12);  
            this.dataGridViewHoaDonPhong.Name = "dataGridViewHoaDonPhong";  
            this.dataGridViewHoaDonPhong.RowHeadersWidth = 51;  
            this.dataGridViewHoaDonPhong.RowTemplate.Height = 24;  
            this.dataGridViewHoaDonPhong.Size = new System.Drawing.Size(776, 378);  
            this.dataGridViewHoaDonPhong.TabIndex = 0;  
            this.dataGridViewHoaDonPhong.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewHoaDonPhong_CellContentClick);  
            //   
            // btnFilterUnpaid  
            //   
            this.btnFilterUnpaid.Location = new System.Drawing.Point(12, 396);  
            this.btnFilterUnpaid.Name = "btnFilterUnpaid";  
            this.btnFilterUnpaid.Size = new System.Drawing.Size(116, 42);  
            this.btnFilterUnpaid.TabIndex = 1;  
            this.btnFilterUnpaid.Text = "Hiện Chưa Thanh Toán";  
            this.btnFilterUnpaid.UseVisualStyleBackColor = true;  
            this.btnFilterUnpaid.Click += new System.EventHandler(this.btnFilterUnpaid_Click);  
            //   
            // btnShowAll  
            //   
            this.btnShowAll.Location = new System.Drawing.Point(142, 396);  
            this.btnShowAll.Name = "btnShowAll";  
            this.btnShowAll.Size = new System.Drawing.Size(116, 42);  
            this.btnShowAll.TabIndex = 2;  
            this.btnShowAll.Text = "Hiện Tất Cả";  
            this.btnShowAll.UseVisualStyleBackColor = true;  
            this.btnShowAll.Click += new System.EventHandler(this.btnShowAll_Click);  
            //   
            // HoaDonPhong  
            //   
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);  
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;  
            this.ClientSize = new System.Drawing.Size(800, 450);  
            this.Controls.Add(this.btnShowAll);  
            this.Controls.Add(this.btnFilterUnpaid);  
            this.Controls.Add(this.dataGridViewHoaDonPhong);  
            this.Name = "HoaDonPhong";  
            this.Text = "Hóa Đơn Phòng";  
            this.Load += new System.EventHandler(this.HoaDonPhong_Load);  
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHoaDonPhong)).EndInit();  
            this.ResumeLayout(false);  
        }  

        private System.Windows.Forms.DataGridView dataGridViewHoaDonPhong;  
        private System.Windows.Forms.Button btnFilterUnpaid;  
        private System.Windows.Forms.Button btnShowAll;  
    }  
}