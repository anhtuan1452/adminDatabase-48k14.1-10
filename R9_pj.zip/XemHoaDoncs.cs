﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace R9
{
    public partial class XemHoaDon : Form
    {
        private string connectionString = "Data Source=PAU\\SQL_DEVELOPER;Initial Catalog=QLyNhaTro;Integrated Security=True";
        private int maHoaDon; // Mã hóa đơn  

        public XemHoaDon(int maHoaDon) // Nhận mã hóa đơn từ constructor  
        {
            InitializeComponent();
            this.maHoaDon = maHoaDon; // Gán mã hóa đơn  
            LoadHoaDonData();
        }

        private void LoadHoaDonData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Lấy thông tin hóa đơn  
                    string queryHoaDon = @"SELECT BHD_idBanghoadon, BHD_ngaylaphoadon, BHD_tongsotien, BHD_tienphong, BHD_trangthai   
                                           FROM BangHoaDon WHERE BHD_idBanghoadon = @maHoaDon";

                    SqlCommand commandHoaDon = new SqlCommand(queryHoaDon, connection);
                    commandHoaDon.Parameters.AddWithValue("@maHoaDon", maHoaDon);

                    SqlDataAdapter adapterHoaDon = new SqlDataAdapter(commandHoaDon);
                    DataTable dtHoaDon = new DataTable();
                    adapterHoaDon.Fill(dtHoaDon);

                    // Hiển thị thông tin hóa đơn  
                    if (dtHoaDon.Rows.Count > 0)
                    {
                        DataRow row = dtHoaDon.Rows[0];
                        lblMaHoaDon.Text = row["BHD_idBanghoadon"].ToString();

                        // Kiểm tra và chuyển đổi trường ngày  
                        lblNgayLapHoaDon.Text = row["BHD_ngaylaphoadon"] != DBNull.Value
                                                ? Convert.ToDateTime(row["BHD_ngaylaphoadon"]).ToString("dd/MM/yyyy")
                                                : "Không có";

                        // Kiểm tra và chuyển đổi trường tiền phòng  
                        lblTienPhong.Text = row["BHD_tienphong"] != DBNull.Value
                                            ? String.Format("{0:N0} VNĐ", Convert.ToInt32(row["BHD_tienphong"]))
                                            : "Không có";

                        // Kiểm tra và chuyển đổi trường trạng thái  
                        lblTrangThai.Text = row["BHD_trangthai"] != DBNull.Value && Convert.ToInt32(row["BHD_trangthai"]) == 0
                                            ? "Chưa thanh toán"
                                            : "Đã thanh toán";
                    }

                    // Lấy thông tin dịch vụ của hóa đơn  
                    string queryDichVu = @"SELECT D.DV_tendichvu, HĐV.soluong, (HĐV.soluong * D.DV_tiencuadichvu) AS ThanhTien  
                                           FROM Hd_Dv HĐV   
                                           INNER JOIN DichVu D ON HĐV.DV_iddichvu = D.DV_iddichvu   
                                           INNER JOIN HoaDonDichVu HĐ ON HĐV.HDDV_idhoadondichvu = HĐ.HDDV_idhoadondichvu   
                                           WHERE HĐ.BHD_idBanghoadon = @maHoaDon";

                    SqlCommand commandDichVu = new SqlCommand(queryDichVu, connection);
                    commandDichVu.Parameters.AddWithValue("@maHoaDon", maHoaDon);

                    SqlDataAdapter adapterDichVu = new SqlDataAdapter(commandDichVu);
                    DataTable dtDichVu = new DataTable();
                    adapterDichVu.Fill(dtDichVu);
                    dataGridViewDichVu.DataSource = dtDichVu; // Hiển thị danh sách dịch vụ  
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi tải thông tin hóa đơn: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}